# Release Governance Platform — Full Codebase

This archive contains a complete production-ready starter codebase for the Release Governance AI Platform.

Folders:
- backend/  (FastAPI app)
- frontend/ (Streamlit UI)

See backend/.env.template for required environment variables and README in root for quick start.
