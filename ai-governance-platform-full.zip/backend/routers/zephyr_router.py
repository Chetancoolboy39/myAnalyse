from fastapi import APIRouter, HTTPException, UploadFile, File
from models.schemas import ZephyrTestCase, ZephyrStep, AttachmentVerifyResult
from services.zephyr_service import create_testcase, add_step_to_testcase, list_attachments_for_testcase
from services.ocr_service import extract_text_from_file
from services.llm_service import rephrase_title_description
from typing import List
import tempfile

router = APIRouter(prefix="/zephyr", tags=["zephyr"])

@router.post("/generate")
def generate_zephyr(jira_key: str, testcase: ZephyrTestCase):
    # Create testcase
    try:
        res = create_testcase(jira_key, testcase.name, testcase.description or "")
        tcid = res.get("id") or res.get("testcaseId") or res.get("key")
        # add steps
        for s in testcase.steps:
            add_step_to_testcase(str(tcid), s.order, s.step, s.expected or "")
        return {"testcase_id": tcid}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/attachments/{testcase_id}")
def get_attachments(testcase_id: str):
    try:
        return list_attachments_for_testcase(testcase_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/attachments/verify", response_model=List[AttachmentVerifyResult])
def verify_attachments(testcase_id: str, step_order: int, file: UploadFile = File(...)):
    try:
        # store temp file
        with tempfile.NamedTemporaryFile(delete=False, suffix="."+file.filename.split(".")[-1]) as tmp:
            tmp.write(file.file.read())
            tmp_path = tmp.name
        text = extract_text_from_file(tmp_path)
        # naive scoring: check overlap of words with step description fetched via API (not implemented)
        # For demo: return 70% match if text not empty
        match_percent = 0.0
        if text and len(text.strip())>20:
            match_percent = 85.0
            status = "Pass"
            comments = "OCR text looks relevant"
        else:
            status = "Fail"
            comments = "No useful text found"
        from models.schemas import AttachmentVerifyResult
        return [AttachmentVerifyResult(step_order=step_order, ocr_text=text, match_percent=match_percent, status=status, comments=comments)]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
