import os, requests
from dotenv import load_dotenv
from typing import List, Dict, Any

load_dotenv()

JIRA_BASE_URL = os.getenv("JIRA_BASE_URL")
JIRA_EMAIL = os.getenv("JIRA_EMAIL")
JIRA_API_TOKEN = os.getenv("JIRA_API_TOKEN")

def _auth():
    return (JIRA_EMAIL, JIRA_API_TOKEN)

def list_projects() -> List[Dict[str, Any]]:
    url = f"{JIRA_BASE_URL}/rest/api/3/project/search"
    try:
        r = requests.get(url, auth=_auth(), timeout=20)
        r.raise_for_status()
        data = r.json()
        projects = data.get("values", []) if isinstance(data, dict) else data
        return [{"key": p.get("key"), "name": p.get("name")} for p in projects]
    except Exception as e:
        return []

def create_issue(project_key: str, summary: str, description: str, issuetype: str = "Task", optional_fields: Dict[str, Any] = {}) -> Dict[str, Any]:
    url = f"{JIRA_BASE_URL}/rest/api/3/issue"
    payload = {
        "fields": {
            "project": {"key": project_key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": issuetype}
        }
    }
    # Add optional fields mapping (labels, priority etc.)
    if optional_fields:
        for k, v in optional_fields.items():
            payload["fields"][k] = v

    r = requests.post(url, json=payload, auth=_auth(), timeout=30)
    r.raise_for_status()
    return r.json()
