import os
import requests
from typing import Tuple, List
from dotenv import load_dotenv

load_dotenv()

LLM_API_URL = os.getenv("LLM_API_URL")
LLM_MODEL = os.getenv("LLM_MODEL", "")

def rephrase_title_description(title: str, description: str) -> Tuple[str, str, str]:
    """ 
    Calls local LLM endpoint to rephrase title & description.
    Returns (new_title, new_description, used_prompt)
    """

    prompt = (
        "You are an expert Jira writer. Rephrase the given title and description " 
        "to follow company Jira standards. Output JSON with keys: title, description.\n\n"
        f"Original Title: {title}\n\nOriginal Description: {description}\n\n"
        "Rephrase rules:\n"
        "- Title: short, include module/context, <=12 words\n"
        "- Description: include Problem, Current Behavior, Expected Behavior, Impact\n"
        "Return only JSON."
    )

    payload = {
        "model": LLM_MODEL,
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that formats Jira tickets."},
            {"role": "user", "content": prompt}
        ],
        "max_tokens": 800
    }

    if not LLM_API_URL:
        # Fallback: echo inputs
        return title, description, prompt

    try:
        r = requests.post(LLM_API_URL, json=payload, timeout=30)
        r.raise_for_status()
        data = r.json()
        # Attempt to parse response. This depends on your LLM's response format.
        content = ""
        if "choices" in data and len(data["choices"]) > 0:
            content = data["choices"][0].get("message", {}).get("content", "")
        elif "result" in data:
            content = data["result"]
        else:
            content = r.text

        # Expect JSON in content
        try:
            import json
            parsed = json.loads(content)
            new_title = parsed.get("title", title)
            new_description = parsed.get("description", description)
            return new_title, new_description, prompt
        except Exception:
            # If not JSON, do a naive split — fallback
            return title, description, prompt
    except Exception as e:
        # On error, return original
        return title, description, prompt
