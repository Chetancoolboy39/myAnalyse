import os, requests
from dotenv import load_dotenv
from typing import Dict, Any, List
load_dotenv()

ZEPHYR_BASE_URL = os.getenv("ZEPHYR_BASE_URL")
ZEPHYR_API_KEY = os.getenv("ZEPHYR_API_KEY")
ZEPHYR_SECRET_KEY = os.getenv("ZEPHYR_SECRET_KEY")

# Note: Zephyr API endpoints differ by product edition. Adapt these functions to your Zephyr instance.

def create_testcase(project_key: str, name: str, description: str) -> Dict[str, Any]:
    """
    Creates a Zephyr test case.
    Adapt endpoint and payload to your Zephyr version.
    """
    url = f"{ZEPHYR_BASE_URL}/public/rest/api/1.0/testcase"
    payload = {
        "projectKey": project_key,
        "name": name,
        "description": description
    }
    headers = {"Content-Type": "application/json"}
    # Add any auth headers if required (API key secret)
    r = requests.post(url, json=payload, headers=headers, timeout=30)
    r.raise_for_status()
    return r.json()

def add_step_to_testcase(testcase_id: str, step_order: int, step: str, expected: str) -> Dict[str, Any]:
    url = f"{ZEPHYR_BASE_URL}/public/rest/api/1.0/testcase/{testcase_id}/step"
    payload = {
        "order": step_order,
        "step": step,
        "expected": expected
    }
    headers = {"Content-Type": "application/json"}
    r = requests.post(url, json=payload, headers=headers, timeout=30)
    r.raise_for_status()
    return r.json()

def list_attachments_for_testcase(testcase_id: str) -> List[Dict[str, Any]]:
    url = f"{ZEPHYR_BASE_URL}/public/rest/api/1.0/testcase/{testcase_id}/attachments"
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    return r.json()
