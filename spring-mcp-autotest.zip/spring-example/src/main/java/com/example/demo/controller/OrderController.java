\
    package com.example.demo.controller;

    import com.example.demo.service.OrderService;
    import org.springframework.http.ResponseEntity;
    import org.springframework.web.bind.annotation.GetMapping;
    import org.springframework.web.bind.annotation.RequestParam;
    import org.springframework.web.bind.annotation.RestController;

    @RestController
    public class OrderController {

        private final OrderService orderService;

        public OrderController(OrderService orderService) {
            this.orderService = orderService;
        }

        @GetMapping("/discount")
        public ResponseEntity<Double> calculateDiscount(
                @RequestParam String orderId,
                @RequestParam double amount,
                @RequestParam double discountPercent
        ) {
            double result = orderService.applyDiscount(orderId, amount, discountPercent);
            return ResponseEntity.ok(result);
        }
    }
