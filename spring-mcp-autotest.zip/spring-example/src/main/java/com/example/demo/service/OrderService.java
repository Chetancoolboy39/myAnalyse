\
    package com.example.demo.service;

    import org.springframework.stereotype.Service;

    @Service
    public class OrderService {

        /**
         * Intentional Sonar issue:
         * - No null check on orderId (possible NPE later)
         * - No validation on amount (could be negative)
         */
        public double applyDiscount(String orderId, double amount, double discountPercent) {
            // BUG: if orderId is null, we still continue (Sonar will complain)
            if (orderId.isEmpty()) {
                throw new IllegalArgumentException("orderId must not be empty");
            }

            // BUG: missing validation for negative amount, Sonar rule about input validation
            double discount = amount * (discountPercent / 100.0);
            return amount - discount;
        }
    }
