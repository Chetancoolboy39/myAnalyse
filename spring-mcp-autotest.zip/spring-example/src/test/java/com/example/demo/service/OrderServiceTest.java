\
    package com.example.demo.service;

    import org.junit.jupiter.api.Test;

    import static org.junit.jupiter.api.Assertions.*;

    class OrderServiceTest {

        private final OrderService orderService = new OrderService();

        @Test
        void applyDiscountShouldCalculateCorrectlyForValidInput() {
            double result = orderService.applyDiscount("ORDER-1", 100.0, 10.0);
            assertEquals(90.0, result);
        }

        // Intentionally missing tests for:
        // - null orderId
        // - negative amount
        // These are good candidates for Copilot + SonarQube auto-generated tests.
    }
