\
    # Spring + SonarQube + MCP + GitHub Copilot Auto Test Example

    This project shows how to use a Python MCP server to connect GitHub Copilot
    to SonarQube so that Copilot can generate **unit tests for all files with issues**
    in a Java Spring Boot project.

    ## Contents

    ```text
    spring-mcp-autotest/
      tools/
        sonar_mcp_server.py         # MCP server talking to SonarQube
      .vscode/
        mcp.json                    # VS Code MCP configuration
      spring-example/
        pom.xml                     # Spring Boot (Maven) project
        src/main/java/com/example/demo/
          DemoApplication.java
          service/OrderService.java
          controller/OrderController.java
        src/test/java/com/example/demo/service/
          OrderServiceTest.java
    ```

    The `OrderService` contains intentional issues (no null check, no validation)
    that SonarQube should report. Copilot can then use the MCP server to read
    those issues and generate unit tests + fixes.

    ---

    ## 1. Prerequisites

    - Java 17
    - Maven
    - Python 3.10+
    - VS Code with:
      - Java Extension Pack
      - Spring Boot Extension Pack
      - GitHub Copilot
      - GitHub Copilot Chat
    - A running SonarQube or SonarCloud instance

    ---

    ## 2. Install Python dependencies for MCP

    From the `spring-mcp-autotest` root:

    ```bash
    pip install "mcp[cli]" requests
    ```

    ---

    ## 3. Configure SonarQube access

    1. Edit `.vscode/mcp.json` if needed:

       ```jsonc
       {
         "servers": {
           "sonarqube-mcp": {
             "type": "stdio",
             "command": "python",
             "args": [
               "${workspaceFolder}/tools/sonar_mcp_server.py"
             ],
             "env": {
               "SONAR_URL": "http://localhost:9000",
               "SONAR_TOKEN": "${env:SONAR_TOKEN}"
             }
           }
         }
       }
       ```

       - Change `SONAR_URL` if your Sonar is not on localhost.

    2. Set the Sonar token as an environment variable (you said you'll add this later):

       - macOS / Linux:

         ```bash
         export SONAR_TOKEN=your_sonar_token_here
         ```

       - Windows PowerShell:

         ```powershell
         $env:SONAR_TOKEN="your_sonar_token_here"
         ```

    ---

    ## 4. Import the Spring example project

    From the `spring-mcp-autotest/spring-example` folder:

    ```bash
    mvn clean test
    ```

    This should run the existing basic test.

    ---

    ## 5. Run a SonarQube analysis (when you are ready)

    When you have your Sonar project created and bound, run (example):

    ```bash
    mvn clean verify sonar:sonar \
      -Dsonar.host.url=http://localhost:9000 \
      -Dsonar.login=$SONAR_TOKEN \
      -Dsonar.projectKey=spring-example
    ```

    You said you'll configure Sonar later, so you can skip this until your Sonar
    setup is ready. Once analyzed, Sonar will show issues for `OrderService`.

    ---

    ## 6. Open workspace in VS Code

    1. Open VS Code in the `spring-mcp-autotest` folder.
    2. VS Code will read `.vscode/mcp.json` and register the `sonarqube-mcp` server.
    3. Make sure the `SONAR_TOKEN` env is set before launching VS Code, so the
       MCP server can authenticate.

    ---

    ## 7. Use Copilot + MCP to generate tests for **all files**

    Open **GitHub Copilot Chat** in VS Code.

    Make sure your SonarQube has analyzed the `spring-example` project and that
    the project key matches (e.g., `spring-example`).

    ### Step 1 – Ask Copilot to get all project issues

    ```text
    Use the `sonarqube-mcp.list_project_issues` tool.

    project_key = "spring-example"
    severities = "BLOCKER,CRITICAL,MAJOR"
    statuses = "OPEN,REOPENED,CONFIRMED"
    types = "BUG,VULNERABILITY,CODE_SMELL"

    Return the JSON and then wait.
    ```

    Copilot will call the MCP tool and show a list of issues with:
    - file path
    - line number
    - rule description
    - code snippet

    ### Step 2 – Ask Copilot to generate unit tests + fixes

    ```text
    For the issues returned by `sonarqube-mcp.list_project_issues`, do the following:

    1. Group the issues by file_path.
    2. For each file:
       a. Summarize the problems using rule_description and code_snippet.
       b. Generate one or more JUnit 5 tests (using Mockito where useful) that reproduce the bug and fail with the current code.
       c. Propose the smallest code changes required in the affected methods to fix the issues.
       d. After the fix, adjust or add tests so that they now pass.

    Use the existing package structure com.example.demo and put tests under
    src/test/java/com/example/demo/**.

    Do NOT rewrite whole files. Only show patches for affected blocks.
    ```

    Copilot will now generate:
    - New tests in `OrderServiceTest` (and other files when added).
    - Patches to fix `OrderService.applyDiscount` (e.g., null checks, negative amount validation).

    You can accept/reject each suggested change.

    ---

    ## 8. Focus on a single file (optional)

    If you only want to work on `OrderService.java`:

    ```text
    Use the `sonarqube-mcp.list_file_issues` tool for this file.

    project_key = "spring-example"
    component_key = "spring-example:src/main/java/com/example/demo/service/OrderService.java"

    Then, for each issue, generate:
    - A failing JUnit 5 test that reproduces it.
    - A minimal fix in OrderService.
    ```

    ---

    ## 9. Coverage-based prompts (optional)

    ```text
    Call `sonarqube-mcp.get_project_coverage` for "spring-example".
    If coverage < 80%, identify which methods in com.example.demo.service are not
    well tested and generate additional unit tests to raise coverage.
    ```

    ---

    ## 10. Summary

    - `tools/sonar_mcp_server.py` connects Copilot to SonarQube via MCP.
    - `spring-example` is a Spring Boot project with intentional issues.
    - You can use Copilot Chat + MCP tools to:
      - Fetch Sonar issues for the whole project.
      - Generate focused unit tests and minimal fixes.
      - Improve coverage in a targeted way.

    You will add your own Sonar project/report later. Once Sonar is configured
    and analysis has run, everything here should work with your real Spring Boot
    projects as well.
