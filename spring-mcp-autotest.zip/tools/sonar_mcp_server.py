\
    #!/usr/bin/env python3
    import os
    from typing import TypedDict, List, Optional, Dict, Any

    import requests
    from mcp.server.fastmcp import FastMCP


    # ================== ENVIRONMENT CONFIG ==================

    SONAR_URL = os.environ.get("SONAR_URL", "").rstrip("/")
    SONAR_TOKEN = os.environ.get("SONAR_TOKEN")

    if not SONAR_URL or not SONAR_TOKEN:
        raise RuntimeError(
            "SONAR_URL and SONAR_TOKEN environment variables must be set for MCP server to run."
        )


    def _auth_headers() -> Dict[str, str]:
        # Using token as Bearer
        return {"Authorization": f"Bearer {SONAR_TOKEN}"}


    def _get_json(path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        resp = requests.get(
            f"{SONAR_URL}{path}", headers=_auth_headers(), params=params, timeout=20
        )
        resp.raise_for_status()
        return resp.json()


    # ================== TYPES FOR RESPONSES ==================


    class IssueSummary(TypedDict, total=False):
        project_key: str
        component_key: str
        file_path: Optional[str]
        issue_key: str
        line: Optional[int]
        end_line: Optional[int]
        severity: str
        type: str
        message: str
        rule_key: str
        rule_name: Optional[str]
        rule_description: Optional[str]
        code_snippet: Optional[str]


    class CoverageInfo(TypedDict):
        project_key: str
        coverage: float


    # ================== MCP SERVER ==================

    mcp = FastMCP("SonarQube-MCP", json_response=True)


    # -------- Helper to enrich issue with rule + snippet --------


    def _enrich_issue(
        issue: Dict[str, Any],
        components_index: Dict[str, Dict[str, Any]],
        project_key: str,
    ) -> IssueSummary:
        comp_key = issue.get("component")
        component = components_index.get(comp_key, {})
        file_path = component.get("path")

        line = issue.get("line")
        end_line = issue.get("endLine")
        rule_key = issue.get("rule")

        # 1) Get rule details (name + description)
        rule_name = None
        rule_desc = None
        if rule_key:
            rule_json = _get_json("/api/rules/show", params={"key": rule_key})
            rule = rule_json.get("rule", {})
            rule_name = rule.get("name")
            rule_desc = (
                rule.get("htmlDesc")
                or rule.get("markdownDescription")
                or rule.get("description")
            )

        # 2) Get code snippet around the issue line
        snippet = None
        if line is not None:
            from_line = max(1, line - 3)
            to_line = (end_line or line) + 3
            src = _get_json(
                "/api/sources/lines",
                params={"key": comp_key, "from": from_line, "to": to_line},
            )
            lines = src.get("sources", [])
            snippet_lines = [
                f"{l.get('line')}: {l.get('code', '')}" for l in lines
            ]
            snippet = "\n".join(snippet_lines) if snippet_lines else None

        return IssueSummary(
            project_key=project_key,
            component_key=comp_key or "",
            file_path=file_path,
            issue_key=issue.get("key", ""),
            line=line,
            end_line=end_line,
            severity=issue.get("severity", ""),
            type=issue.get("type", ""),
            message=issue.get("message", ""),
            rule_key=rule_key or "",
            rule_name=rule_name,
            rule_description=rule_desc,
            code_snippet=snippet,
        )


    # ================== TOOLS ==================


    @mcp.tool()
    def list_file_issues(
        project_key: str,
        component_key: str,
        severities: str = "BLOCKER,CRITICAL,MAJOR",
        statuses: str = "OPEN,REOPENED,CONFIRMED",
    ) -> List[IssueSummary]:
        """
        Get SonarQube issues for a single file/component.
        Useful when you only want to focus on the currently opened file.
        """
        data = _get_json(
            "/api/issues/search",
            params={
                "projectKeys": project_key,
                "componentKeys": component_key,
                "severities": severities,
                "statuses": statuses,
                "ps": 500,
                "p": 1,
            },
        )

        issues = data.get("issues", [])
        components_index = {c["key"]: c for c in data.get("components", [])}

        results: List[IssueSummary] = []
        for issue in issues:
            results.append(_enrich_issue(issue, components_index, project_key))

        return results


    @mcp.tool()
    def list_project_issues(
        project_key: str,
        severities: str = "BLOCKER,CRITICAL,MAJOR",
        statuses: str = "OPEN,REOPENED,CONFIRMED",
        types: str = "BUG,VULNERABILITY,CODE_SMELL",
        page_size: int = 200,
        max_pages: int = 10,
    ) -> List[IssueSummary]:
        """
        Get issues for the entire SonarQube project (multiple files).
        Copilot can then iterate this list and generate unit tests for all affected files.

        Args:
          project_key: SonarQube project key.
          severities: Comma-separated severities to include.
          statuses: Comma-separated statuses to include.
          types: Comma-separated issue types (BUG, VULNERABILITY, CODE_SMELL).
          page_size: Issues per page.
          max_pages: Safety limit for large projects.
        """
        all_results: List[IssueSummary] = []
        components_index: Dict[str, Dict[str, Any]] = {}

        for page in range(1, max_pages + 1):
            data = _get_json(
                "/api/issues/search",
                params={
                    "projectKeys": project_key,
                    "severities": severities,
                    "statuses": statuses,
                    "types": types,
                    "ps": page_size,
                    "p": page,
                },
            )

            issues = data.get("issues", [])
            if not issues:
                break

            # Merge components into index
            for c in data.get("components", []):
                components_index[c["key"]] = c

            for issue in issues:
                all_results.append(_enrich_issue(issue, components_index, project_key))

            # Stop if fewer results than page_size (no more pages)
            if len(issues) < page_size:
                break

        return all_results


    @mcp.tool()
    def get_project_coverage(project_key: str) -> CoverageInfo:
        """
        Get overall project coverage. Copilot can use this to decide where to
        focus test generation (e.g. if coverage < 80%).
        """
        data = _get_json(
            "/api/measures/component",
            params={"component": project_key, "metricKeys": "coverage"},
        )
        measures = (data.get("component") or {}).get("measures") or []
        coverage_str = next(
            (m.get("value") for m in measures if m.get("metric") == "coverage"), "0"
        )
        return CoverageInfo(project_key=project_key, coverage=float(coverage_str or 0.0))


    if __name__ == "__main__":
        # Standard stdio MCP server
        mcp.run(transport="stdio")
